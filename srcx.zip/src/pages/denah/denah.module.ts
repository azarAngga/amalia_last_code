import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DenahPage } from './denah';

@NgModule({
  declarations: [
    DenahPage,
  ],
  imports: [
    IonicPageModule.forChild(DenahPage),
  ],
})
export class DenahPageModule {}
